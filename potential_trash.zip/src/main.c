#include <zephyr/kernel.h>
#include <zephyr/drivers/gpio.h>
#include "ws2812.h"

// External pattern functions
void pattern_wave(void);
void pattern_ball(void);
void pattern_breath(void);
void pattern_twinkle(void);
void pattern_flash_burst(void);

// Semaphore for button interrupt
K_SEM_DEFINE(button_sem, 0, 1);

// Button configuration
static const struct gpio_dt_spec button = GPIO_DT_SPEC_GET(DT_ALIAS(button0), gpios);
static struct gpio_callback button_cb_data;

// Button ISR
void button_pressed(const struct device *dev, struct gpio_callback *cb, uint32_t pins) {
    k_sem_give(&button_sem);
}

// Thread 1: Wave pattern
void wave_thread(void *a, void *b, void *c) {
    while (1) {
        k_mutex_lock(&matrix_mutex, K_FOREVER);
        pattern_wave();
        k_mutex_unlock(&matrix_mutex);
        k_msleep(100);
    }
}

// Thread 2: Ball pattern
void ball_thread(void *a, void *b, void *c) {
    while (1) {
        k_mutex_lock(&matrix_mutex, K_FOREVER);
        pattern_ball();
        k_mutex_unlock(&matrix_mutex);
        k_msleep(50);
    }
}

// Thread 3: Breathing border
void breath_thread(void *a, void *b, void *c) {
    while (1) {
        k_mutex_lock(&matrix_mutex, K_FOREVER);
        pattern_breath();
        k_mutex_unlock(&matrix_mutex);
        k_msleep(50);
    }
}

// Thread 4: Twinkle
void twinkle_thread(void *a, void *b, void *c) {
    while (1) {
        k_mutex_lock(&matrix_mutex, K_FOREVER);
        pattern_twinkle();
        k_mutex_unlock(&matrix_mutex);
        k_msleep(100);
    }
}

// Thread 5: Display update
void display_thread(void *a, void *b, void *c) {
    while (1) {
        k_mutex_lock(&matrix_mutex, K_FOREVER);
        ws2812_update();
        k_mutex_unlock(&matrix_mutex);
        k_msleep(20);  // 50 FPS
    }
}

// Thread 6: Button handler (highest priority)
void button_thread(void *a, void *b, void *c) {
    while (1) {
        k_sem_take(&button_sem, K_FOREVER);
        pattern_flash_burst();
    }
}

// Define threads with priorities (lower number = higher priority)
K_THREAD_DEFINE(button_tid, 1024, button_thread, NULL, NULL, NULL, 3, 0, 0);
K_THREAD_DEFINE(wave_tid, 1024, wave_thread, NULL, NULL, NULL, 5, 0, 0);
K_THREAD_DEFINE(ball_tid, 1024, ball_thread, NULL, NULL, NULL, 6, 0, 0);
K_THREAD_DEFINE(breath_tid, 1024, breath_thread, NULL, NULL, NULL, 7, 0, 0);
K_THREAD_DEFINE(twinkle_tid, 1024, twinkle_thread, NULL, NULL, NULL, 8, 0, 0);
K_THREAD_DEFINE(display_tid, 1024, display_thread, NULL, NULL, NULL, 4, 0, 0);

int main(void) {
    printk("LED Matrix Multi-Threading Demo\n");
    
    // Initialize WS2812
    if (ws2812_init() != 0) {
        printk("Failed to initialize WS2812\n");
        return -1;
    }
    
    // Configure button
    if (!device_is_ready(button.port)) {
        printk("Button device not ready\n");
        return -1;
    }
    
    gpio_pin_configure_dt(&button, GPIO_INPUT);
    gpio_pin_interrupt_configure_dt(&button, GPIO_INT_EDGE_TO_ACTIVE);
    gpio_init_callback(&button_cb_data, button_pressed, BIT(button.pin));
    gpio_add_callback(button.port, &button_cb_data);
    
    printk("Demo started! Press button for interrupt animation\n");
    
    // Main thread just sleeps - worker threads do all the work
    while (1) {
        k_msleep(10000);
    }
    
    return 0;
}