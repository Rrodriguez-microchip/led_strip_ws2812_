#include "ws2812.h"
#include <zephyr/device.h>
#include <zephyr/drivers/spi.h>
#include <zephyr/drivers/gpio.h>

// LED buffer
static rgb_t led_buffer[NUM_LEDS];

// Mutex for thread-safe access
K_MUTEX_DEFINE(matrix_mutex);

// SPI device
static const struct device *spi_dev;
static struct spi_config spi_cfg = {
    .frequency = 3200000,  // 3.2 MHz for WS2812 timing approximation
    .operation = SPI_WORD_SET(8) | SPI_TRANSFER_MSB,
    .slave = 0,
    .cs = NULL,
};

// WS2812 bit patterns (SPI encoding)
// For WS2812: 0 = 0.4us high + 0.85us low, 1 = 0.8us high + 0.45us low
// Using SPI at 3.2MHz: Each bit = 312.5ns
// 0 -> 0b11000000 (2 high bits, 6 low) ≈ 0.4us high
// 1 -> 0b11111000 (5 high bits, 3 low) ≈ 0.8us high
#define WS2812_0 0xC0
#define WS2812_1 0xF8

int ws2812_init(void) {
    spi_dev = DEVICE_DT_GET(DT_NODELABEL(spi1));
    if (!device_is_ready(spi_dev)) {
        return -ENODEV;
    }
    
    ws2812_clear();
    ws2812_update();
    return 0;
}

void ws2812_set_pixel(uint8_t x, uint8_t y, rgb_t color) {
    if (x >= MATRIX_WIDTH || y >= MATRIX_HEIGHT) return;
    
    // Convert x,y to linear index (depends on your matrix wiring)
    // This assumes zigzag wiring pattern - adjust for your matrix
    uint16_t index;
    if (y % 2 == 0) {
        index = y * MATRIX_WIDTH + x;
    } else {
        index = y * MATRIX_WIDTH + (MATRIX_WIDTH - 1 - x);
    }
    
    led_buffer[index] = color;
}

rgb_t ws2812_get_pixel(uint8_t x, uint8_t y) {
    if (x >= MATRIX_WIDTH || y >= MATRIX_HEIGHT) {
        return (rgb_t){0, 0, 0};
    }
    
    uint16_t index;
    if (y % 2 == 0) {
        index = y * MATRIX_WIDTH + x;
    } else {
        index = y * MATRIX_WIDTH + (MATRIX_WIDTH - 1 - x);
    }
    
    return led_buffer[index];
}

void ws2812_clear(void) {
    memset(led_buffer, 0, sizeof(led_buffer));
}

void ws2812_update(void) {
    // Convert RGB to SPI bit pattern
    uint8_t spi_buf[NUM_LEDS * 3 * 4]; // Each color byte -> 4 SPI bytes
    uint16_t spi_idx = 0;
    
    for (int i = 0; i < NUM_LEDS; i++) {
        // WS2812 order is GRB
        uint8_t colors[3] = {led_buffer[i].g, led_buffer[i].r, led_buffer[i].b};
        
        for (int c = 0; c < 3; c++) {
            for (int bit = 7; bit >= 0; bit--) {
                spi_buf[spi_idx++] = (colors[c] & (1 << bit)) ? WS2812_1 : WS2812_0;
            }
        }
    }
    
    struct spi_buf tx_buf = {
        .buf = spi_buf,
        .len = sizeof(spi_buf)
    };
    struct spi_buf_set tx = {
        .buffers = &tx_buf,
        .count = 1
    };
    
    spi_write(spi_dev, &spi_cfg, &tx);
    
    // WS2812 needs >50us reset time
    k_usleep(60);
}