#include "ws2812.h"
#include <math.h>

// Pattern 1: Scrolling wave
static int wave_offset = 0;

void pattern_wave(void) {
    for (int y = 0; y < MATRIX_HEIGHT; y++) {
        for (int x = 0; x < MATRIX_WIDTH; x++) {
            // Create sine wave pattern
            int wave_pos = (x + wave_offset) % MATRIX_WIDTH;
            uint8_t brightness = (uint8_t)(128 + 127 * sin(wave_pos * 3.14159 / 8.0));
            
            rgb_t color = {0, brightness, 0};  // Red wave
            ws2812_set_pixel(x, y, color);
        }
    }
    wave_offset = (wave_offset + 1) % MATRIX_WIDTH;
}

// Pattern 2: Bouncing ball
static float ball_x = 8.0, ball_y = 8.0;
static float ball_vx = 0.3, ball_vy = 0.2;

void pattern_ball(void) {
    // Update ball physics
    ball_x += ball_vx;
    ball_y += ball_vy;
    
    if (ball_x <= 0 || ball_x >= MATRIX_WIDTH - 1) ball_vx = -ball_vx;
    if (ball_y <= 0 || ball_y >= MATRIX_HEIGHT - 1) ball_vy = -ball_vy;
    
    // Draw ball (3x3)
    for (int dy = -1; dy <= 1; dy++) {
        for (int dx = -1; dx <= 1; dx++) {
            int px = (int)ball_x + dx;
            int py = (int)ball_y + dy;
            if (px >= 0 && px < MATRIX_WIDTH && py >= 0 && py < MATRIX_HEIGHT) {
                rgb_t current = ws2812_get_pixel(px, py);
                current.b = 255;  // Add blue
                ws2812_set_pixel(px, py, current);
            }
        }
    }
}

// Pattern 3: Breathing border
static uint8_t breath_brightness = 0;
static int8_t breath_direction = 1;

void pattern_breath(void) {
    breath_brightness += breath_direction * 5;
    if (breath_brightness >= 250 || breath_brightness <= 5) {
        breath_direction = -breath_direction;
    }
    
    // Draw border
    for (int x = 0; x < MATRIX_WIDTH; x++) {
        rgb_t current_top = ws2812_get_pixel(x, 0);
        rgb_t current_bottom = ws2812_get_pixel(x, MATRIX_HEIGHT - 1);
        current_top.g = breath_brightness;
        current_bottom.g = breath_brightness;
        ws2812_set_pixel(x, 0, current_top);
        ws2812_set_pixel(x, MATRIX_HEIGHT - 1, current_bottom);
    }
    for (int y = 1; y < MATRIX_HEIGHT - 1; y++) {
        rgb_t current_left = ws2812_get_pixel(0, y);
        rgb_t current_right = ws2812_get_pixel(MATRIX_WIDTH - 1, y);
        current_left.g = breath_brightness;
        current_right.g = breath_brightness;
        ws2812_set_pixel(0, y, current_left);
        ws2812_set_pixel(MATRIX_WIDTH - 1, y, current_right);
    }
}

// Pattern 4: Random twinkle
void pattern_twinkle(void) {
    // Add a few random white pixels
    for (int i = 0; i < 3; i++) {
        int x = sys_rand32_get() % MATRIX_WIDTH;
        int y = sys_rand32_get() % MATRIX_HEIGHT;
        uint8_t brightness = sys_rand32_get() % 128 + 128;
        
        rgb_t current = ws2812_get_pixel(x, y);
        current.r = MIN(255, current.r + brightness / 3);
        current.g = MIN(255, current.g + brightness / 3);
        current.b = MIN(255, current.b + brightness / 3);
        ws2812_set_pixel(x, y, current);
    }
    
    // Fade all pixels slightly
    for (int y = 0; y < MATRIX_HEIGHT; y++) {
        for (int x = 0; x < MATRIX_WIDTH; x++) {
            rgb_t current = ws2812_get_pixel(x, y);
            current.r = current.r * 0.95;
            current.g = current.g * 0.95;
            current.b = current.b * 0.95;
            ws2812_set_pixel(x, y, current);
        }
    }
}

// ISR Pattern: Flash burst
void pattern_flash_burst(void) {
    for (int frame = 0; frame < 10; frame++) {
        uint8_t brightness = 255 - (frame * 25);
        
        k_mutex_lock(&matrix_mutex, K_FOREVER);
        for (int y = 0; y < MATRIX_HEIGHT; y++) {
            for (int x = 0; x < MATRIX_WIDTH; x++) {
                ws2812_set_pixel(x, y, (rgb_t){brightness, brightness, 0});
            }
        }
        ws2812_update();
        k_mutex_unlock(&matrix_mutex);
        
        k_msleep(30);
    }
}